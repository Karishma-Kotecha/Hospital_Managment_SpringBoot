package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PatientController {
	
	@Autowired
    PatientRepository patientRepository;
	
	@RequestMapping("/")
	public String index_1()
	{
		return"index_1";
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)    
	public ModelAndView save(@ModelAttribute Patient patient)  
	{    
	patientRepository.save(patient);
	ModelAndView modelAndView = new ModelAndView();    
	modelAndView.setViewName("patient_data");        
	
	modelAndView.addObject("Patient", patient);      
	return modelAndView;    
	}    

	
}
	