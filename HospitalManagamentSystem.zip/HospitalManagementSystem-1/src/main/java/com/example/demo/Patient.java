package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long PatientId;
    private String PatientName;
    private int PatientAge;
    private String PatientDiagnosis;
    
 // Getters and Setters
	public Long getPatientId() {
		return PatientId;
	}
	public void setPatientId(Long patientId) {
		PatientId = patientId;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public int getPatientAge() {
		return PatientAge;
	}
	public void setPatientAge(int patientAge) {
		PatientAge = patientAge;
	}
	public String getPatientDiagnosis() {
		return PatientDiagnosis;
	}
	public void setPatientDiagnosis(String patientDiagnosis) {
		PatientDiagnosis = patientDiagnosis;
	}
    
    
	}


